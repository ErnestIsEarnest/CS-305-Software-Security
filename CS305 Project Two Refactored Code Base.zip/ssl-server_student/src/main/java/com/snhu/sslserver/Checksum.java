package com.snhu.sslserver;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.security.MessageDigest; 


public class Checksum {
	
	
	public Checksum() {
				
	}
	
	String checksum(final MessageDigest digest, final Object obj) {
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(bos);
			oos.writeObject(obj);
			oos.flush();
		} catch (IOException e) {
			e.getMessage();
			e.printStackTrace();
		}
		byte [] b = bos.toByteArray();
		digest.update(b);
		b = digest.digest();
		
		StringBuilder sb = new StringBuilder();
		
		for (byte bytes : b ) {
			sb.append(String.format("%02X ", bytes));
		}
		
		return sb.toString();
	}
	
	
	
}