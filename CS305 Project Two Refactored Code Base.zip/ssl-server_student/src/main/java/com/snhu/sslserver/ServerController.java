package com.snhu.sslserver;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController; 

@RestController
class ServerController {
	
	private static final String template = "Hello, %s!";
	private String data;
	private MessageDigest digest;
	
	@RequestMapping("/hash")
	public String myHash(@RequestParam(value = "name", defaultValue = "Ernest") String name, @RequestParam(value = "algorithm", defaultValue = "SHA-384") String algorithm)
		throws NoSuchAlgorithmException {
		
	data = name;
	
	try{
			
			try{
					
					digest = MessageDigest.getInstance(algorithm);
					
				} catch (NoSuchAlgorithmException e) {
						
						return data + "hash failed. " + algorithm + " not available to use for hashing. "
								+ "Maybe it doesn't exist?" + "<p>" + e.getMessage();
					}
		
					Checksum chk = new Checksum();
					
					String hash = chk.checksum(digest, data);
					chk = null;
					
					return String.format(template, name) + "<p>" +
					"Hash Algorithm: " + digest.getAlgorithm() + "<p>" 
					+ "Name Checksum Value: " + hash;
					
		} catch (Exception e) {
			
			return data + " hash failed, unknown error.<p>" + e.getMessage();
		}
	
	
	}
	
}